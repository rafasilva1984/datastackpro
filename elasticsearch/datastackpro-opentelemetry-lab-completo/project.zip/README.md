# Projeto DataStackPro OTEL Lab

(README será completado ao subir no GitHub)